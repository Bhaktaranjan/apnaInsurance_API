const connection = require('../db/db-connection');
const { multipleColumnSet } = require('../utils/common.utils');
const logger = require('../middleware/logger');

const tableName = 'model_variant';

exports.getAllModelVariantsQuery = async (params = {}) => {
    // Construct the base SQL query
    let sql = `SELECT * FROM ${tableName}`;
    logger.info(`DB Query: Get AllModelVariants Sql: ${sql}`);

    // Check if there are any additional filter parameters
    if (!Object.keys(params).length) {
        // If not, execute the query and return the result
        return await connection.query(sql);
    }

    // Generate the column set and values for the filter parameters
    const { columnSet, values } = multipleColumnSet(params);

    // Append the filter condition to the SQL query
    sql += ` WHERE ${columnSet}`;

    // Execute the query with the filter parameters and return the result
    return await connection.query(sql, [...values]);
}

exports.createModelVariantQuery = async ({ Name, VehicleModelId, ManufacturerId }) => {
    // Create the SQL query
    const sql = `INSERT INTO ${tableName} (Name, VehicleModelId, ManufacturerId) VALUES (?,?,?)`;

    // Log the SQL query
    logger.info(` DB Query : Create ModelVariant Sql : ${sql}`);

    // Execute the SQL query and get the result
    const result = await connection.query(sql, [Name, VehicleModelId, ManufacturerId]);
}

exports.updateModelVariantQuery = async (params, id) => {
    const { columnSet, values } = multipleColumnSet(params);
    const sql = `UPDATE ${tableName} SET ${columnSet} WHERE id = ?`;

    logger.info(`DB Query : Update ModelVariant Sql : ${sql}`);

    const result = await connection.query(sql, [...values, id]);

    return result;
}

exports.deleteModelVariantQuery = async (id) => {
    const sql = `DELETE FROM ${tableName} WHERE id = ?`;

    logger.info(`DB Query : Delete ModelVariant Sql : ${sql}`);

    const result = await connection.query(sql, [id]);

    return result;
}